
const Sequelize = require('sequelize');
module.exports = (app, db) => {


  var multer = require('multer')
  var upload = multer({ dest: 'uploads/' })
  app.post("/test", (req, res) =>
    res.json("result")
  );

  app.post("/upload_video1", (req, res) => {

    return res.json(["Tony", "Lisa", "Michael", "Ginger", "Food"]);
  });
  app.post("/upload_video", upload.single('file'), (req, res) => {


    console.log("ree", req.file);
    if (!req.file) {
      return res.json(false)
    }
    // return res.json("sss");
    // return res.json(req.file)
    var fs = require("fs");
    var tus = require("tus-js-client");
    var path = __dirname + "/../../test.mp4";
    var path = req.file.path;
    var file = fs.createReadStream(path);
    var size = fs.statSync(path).size;

    var account = "59da0cdbb576ae7a2ba696b38e68317e";
    var zone = "49c56b237c721c9b6e32c49fc4e049d9";
    var email = "ahmad.alhourani.ite90@gmail.com";

    var apiKey = "6bb216873ca0923bf06d8f3e826ffbe9d349c";

    var options = {
      endpoint: "https://api.cloudflare.com/client/v4/accounts/" + account + "/stream",
      headers: {
        'X-Auth-Email': email,
        'X-Auth-Key': apiKey,
      },
      chunkSize: 5 * 1024 * 1024, // Cloudflare Stream requires a minimum chunk size of 5MB.
      resume: true,
      metadata: {
        filename: "test.mp4",
        filetype: "video/mp4"
      },
      uploadSize: size,
      onError: function (error) {
        throw error;
      },
      onProgress: function (bytesUploaded, bytesTotal) {
        var percentage = (bytesUploaded / bytesTotal * 100).toFixed(2);
        console.log(bytesUploaded, bytesTotal, percentage + "%");
      },
      onSuccess: function () {
        console.log("Upload finished:", upload.url);
        var index = upload.url.lastIndexOf("/") + 1;
        var mediaId = upload.url.substr(index)
        console.log("Media id:", mediaId);

        db.media.create({
          name: req.file.originalname,
          uuid: mediaId,
          type: req.file.mimetype,

        }).then((result) => res.json(mediaId))

        // res.json(mediaId);
      }
    };

    var upload = new tus.Upload(file, options);
    upload.start();



  }
  ),
    app.get("/media", (req, res) =>
      db.media.findAll(
        {
        }

      ).then((result) => res.json(result))
    );

}